package pe.edu.upc.medlearn.controllers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.medlearn.dtos.RoleDTO;
import pe.edu.upc.medlearn.dtos.UserDTO;
import pe.edu.upc.medlearn.dtos.UserListDTO;
import pe.edu.upc.medlearn.entities.Role;
import pe.edu.upc.medlearn.entities.Users;
import pe.edu.upc.medlearn.servicesinterfaces.IRoleService;
import pe.edu.upc.medlearn.servicesinterfaces.IUserService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin
public class CrearCuentaController {
    @Autowired
    private IUserService uS;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @PostMapping("/crearcuenta")
    public void insert(@RequestBody UserDTO dto) {
        dto.setEnabled(true);
        ModelMapper m = new ModelMapper();
        Users user = m.map(dto, Users.class);
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
        uS.insert(user);
    }
    @Autowired
    private IRoleService rS;
    @PostMapping("/registrarrole")
    public  void registrar(@RequestBody RoleDTO dto){
        ModelMapper m = new ModelMapper();
        Role r = m.map(dto, Role.class);
        rS.insert(r);
    }

    @PostMapping("/usuarios/{id}/roles")
    public void registrarRol(@PathVariable("id") Integer idUs, @RequestParam String rol){
        uS.insRol(rol,idUs);
    }

    @GetMapping("/idmayor")
    public int mayor(){
        return uS.idUsuarioMayor();
    }

    @GetMapping("/listarini")
    public List<UserListDTO> listar() {
        return uS.list().stream().map(x -> {
            ModelMapper m = new ModelMapper();
            return m.map(x, UserListDTO.class);
        }).collect(Collectors.toList());
    }
}
