package pe.edu.upc.medlearn.servicesinterfaces;

import org.springframework.data.repository.query.Param;
import pe.edu.upc.medlearn.entities.Diet;
import pe.edu.upc.medlearn.entities.Food;

import java.util.List;

public interface IDietService {
    public List<Diet> list();
    public void insert(Diet diet);
    public Diet listId(int id);
    public void update(Diet a);
    public void delete(int id);

    List<Diet> findByQualification(int qualification);
    List<Diet> findByDescription(String description);
    List<Diet> listByIllness(int idillness);
    //HUB60
    List<String[]> quantityBydietsinicidasandfinalizadasporusuario();
    List<Diet> listByUser( int iduser);


}
