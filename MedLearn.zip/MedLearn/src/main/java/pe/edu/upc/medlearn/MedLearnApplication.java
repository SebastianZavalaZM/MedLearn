package pe.edu.upc.medlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedLearnApplication {

    public static void main(String[] args) {
        SpringApplication.run(MedLearnApplication.class, args);
    }

}
