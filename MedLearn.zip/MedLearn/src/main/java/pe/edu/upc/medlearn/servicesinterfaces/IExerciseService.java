package pe.edu.upc.medlearn.servicesinterfaces;

import org.springframework.data.repository.query.Param;
import pe.edu.upc.medlearn.entities.Diet;
import pe.edu.upc.medlearn.entities.Exercise;

import java.util.List;

public interface IExerciseService {
    public List<Exercise> list();
    public void insert(Exercise exercise);
    public Exercise listId(int id);
    public void delete(int id);
    public List<Exercise> buscarNombre(String nombre);

    public List<String[]>totaldeexercisesbyDietas();
    List<Exercise> listByDiet(@Param("iddiet") int iddiet);
}
