package pe.edu.upc.medlearn.dtos;

public class FindIlilnessSymptomsDTO {
    private String nameSymptom;


    public String getNameSymptom() {
        return nameSymptom;
    }

    public void setNameSymptom(String nameSymptom) {
        this.nameSymptom = nameSymptom;
    }

}
