package pe.edu.upc.medlearn.dtos;

public class TopTreatmentsDTO {

    private String treatmentName;
    private int usersCount;

    public String getTreatmentName() {
        return treatmentName;
    }

    public void setTreatmentName(String treatmentName) {
        this.treatmentName = treatmentName;
    }

    public int getUsersCount() {
        return usersCount;
    }

    public void setUsersCount(int usersCount) {
        this.usersCount = usersCount;
    }


}
