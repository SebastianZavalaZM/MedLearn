package pe.edu.upc.medlearn.servicesinterfaces;

import org.springframework.data.repository.query.Param;
import pe.edu.upc.medlearn.entities.Diet;
import pe.edu.upc.medlearn.entities.Users;

import java.util.List;

public interface IUserService {
    public List<Users> list();
    public void insert(Users user);
    public Users listId(int id);
    public List<Users> search(String name);
    public List<String[]> cantidadUsuariosPorRol();
    public void update(Users us);
    public int idUsuarioMayor();
    public void insRol(String authority, int user_id);
}
